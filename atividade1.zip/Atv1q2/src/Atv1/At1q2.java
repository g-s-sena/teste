package Atv1;

import java.util.Scanner;

public class At1q2 {

	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o numero da mesa: ");
        int numMesa = sc.nextInt();
        sc.nextLine();

        String[] nomes = new String[2];
        double[] val = new double[2];
        int[] quant = new int[2];
        double valTotal = 0.0;

        for (int i = 0; i < 2; i++) {
            System.out.println("\n--- Inserindo o " + (i + 1) + "o item ---");

            System.out.print("Nome do produto: ");
            nomes[i] = sc.nextLine();

            System.out.print("Valor unitario: ");
            val[i] = sc.nextDouble();

            System.out.print("Quantidade: ");
            quant[i] = sc.nextInt();
            sc.nextLine(); 
        }

        System.out.println("\n------------------------");
        System.out.println("      Comanda da Mesa: " + numMesa);
        System.out.println("------------------------");
        
        for (int i = 0; i < 2; i++) {
            double subtotal = val[i] * quant[i];
            valTotal += subtotal;
            System.out.printf("Produto: %s, Qtd: %d, Valor: R$ %.2f\n",
                    nomes[i], quant[i], subtotal);
        }

        System.out.println("--------------------");
        System.out.printf("VALOR TOTAL: R$%.2f\n", valTotal);
        System.out.println("--------------------");

        sc.close();
    }
}
