package atv;

import java.util.Scanner;

public class Atv1 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o nome do professor: ");
        String prof = sc.nextLine();

        System.out.println("\nDigite o nome do aluno: ");
        String aluno = sc.nextLine();

        System.out.println("\nDigite a primeira nota: ");
        float  nota = sc.nextInt();
        System.out.println("\nDigite a segunda nota: ");
        float  nota2 = sc.nextInt();

        float media =  (nota + nota2) / 2;

        System.out.printf("Nome do professor: %s\nNome do aluno %s\nNota 1: %.2f\nNota 2: %.2f\nMedia: %.2f", prof, aluno, nota, nota2, media);

        sc.close();
    }
}