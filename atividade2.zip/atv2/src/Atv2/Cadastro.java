package Atv2;

public class Cadastro {
    String nome;
    String telefone;
    String endereco;
}
