package Atv2;

public class Acessorio {
    String nome;
    int quantidade;
}
