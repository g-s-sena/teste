package Atv2;

import java.util.Scanner;

public class Atv2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int senha;
         
        do {
            System.out.print("Digite a senha: ");
            senha = sc.nextInt();
            if (senha != 123) {
                System.out.println("ERRO DE SENHA\n");
            } else {
                System.out.println("SENHA CORRETA\n");
            }
        } while (senha != 123);

        int op;
        
        do {
            System.out.println("--- MENU PRINCIPAL ---");
            System.out.println("1 - Cadastro de cliente");
            System.out.println("2 - Compra de carro");
            System.out.println("3 - Compra de acessório");
            System.out.println("4 - Sair");
            System.out.print("Escolha uma opção: ");
            
            op = sc.nextInt();
            sc.nextLine(); 

            switch (op) {
                case 1:
                	
                    System.out.println("\n--- CADASTRO ---");
                    Cadastro cliente = new Cadastro();
                    
                    System.out.print("Digite o nome do cliente: ");
                    cliente.nome = sc.nextLine();
                    
                    System.out.print("Digite o telefone: ");
                    cliente.telefone = sc.nextLine();
                    
                    System.out.print("Digite o endereço: ");
                    cliente.endereco = sc.nextLine();
                    
                    System.out.println("Cliente cadastrado com sucesso!\n");
                    break;
                    
                case 2:

                    System.out.println("\n--- COMPRA DE CARRO ---");
                    System.out.println("Escolha um carro:");
                    System.out.println("1 - Fiat Argo");
                    System.out.println("2 - Chevrolet Onix");
                    System.out.println("3 - Toyota Corolla");

                    int esc = sc.nextInt();
                    sc.nextLine(); 

                    Carro carro = null;

                    switch (esc) {
                        case 1:
                            carro = new Carro("Fiat Argo");
                            break;
                        case 2:
                            carro = new Carro("Chevrolet Onix");
                            break;
                        case 3:
                            carro = new Carro("Toyota Corolla");
                            break;
                        default:
                            System.out.println("Opção inválida.");
                            break;
                    }

                    if (carro != null) {
                        System.out.println("Você escolheu o carro: " + carro.getNome());
                        
                        System.out.print("Digite a cor do carro: "); 
                        String cor = sc.nextLine();
                        
                        int forma;
                        String formaPagamento = "";

                        do {
	                        System.out.print("Digite a forma de pagamento ([1] à vista / [2] parcelado): ");
	                        forma = sc.nextInt();
	                        if(forma == 1) {
	                        	formaPagamento = "à vista";
	                        } else if (forma == 2) {
	                        	formaPagamento = "parcelado";
	                        }
                        } while (forma != 1 && forma != 2);
                        
                        System.out.println("Compra do " + carro.getNome() + " cor " + cor + " registrada! Pagamento: " + formaPagamento + "\n");
                    }
                    break;
                    
                case 3:

                    System.out.println("\n--- COMPRA DE ACESSÓRIO ---");
                    Acessorio acessorio = new Acessorio();

                    System.out.print("Digite o nome do acessório: ");
                    acessorio.nome = sc.nextLine();

                    System.out.print("Digite a quantidade: ");
                    acessorio.quantidade = sc.nextInt();
                    sc.nextLine();

                    System.out.println("Compra registrada: " + acessorio.quantidade + "x " + acessorio.nome + "\n");
                    break;
                    
                case 4:
                    System.out.println("Saindo do programa...");
                    break;
                    
                default:
                    System.out.println("Opção inválida. Tente novamente.\n");
                    break;
            }

        } while (op != 4); 

        sc.close();
    }
}